/*
 * Exported with nin10kit v1.3
 * Invocation command was nin10kit -mode=3 start start.png 
 * Time-stamp: Wednesday 11/09/2016, 02:40:12
 * 
 * Image Information
 * -----------------
 * start.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef START_H
#define START_H

extern const unsigned short start[38400];
#define START_SIZE 38400
#define START_WIDTH 240
#define START_HEIGHT 160

#endif

