/*
 * Exported with nin10kit v1.3
 * Invocation command was nin10kit -mode=3 gameover gameover.png 
 * Time-stamp: Tuesday 11/08/2016, 23:29:32
 * 
 * Image Information
 * -----------------
 * gameover.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef GAMEOVER_H
#define GAMEOVER_H

extern const unsigned short gameover[38400];
#define GAMEOVER_SIZE 38400
#define GAMEOVER_WIDTH 240
#define GAMEOVER_HEIGHT 160

#endif

